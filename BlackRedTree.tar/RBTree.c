/**
 * @file RBTree.c
 * @author shahar cohen <shahar.cohen10@mail.huji.ac.il>
 * @cs user: shaharc1994
 * @id 205801541
 * @brief ex3, generic data ,binary tree
 */

#include <stdlib.h>
#include "RBTree.h"

#define SUCCESS 1
#define FAILURE 0

/**
 * constructs a new RBTree with the given CompareFunc.
 * comp: a function two compare two variables.
 */
RBTree *newRBTree(CompareFunc compFunc, FreeFunc freeFunc)
{
	RBTree  *NRBTree = (RBTree*) malloc(sizeof(RBTree));
	if (NRBTree == NULL)
	{
		return NULL;
	}
	NRBTree -> root = NULL;
	NRBTree -> compFunc = compFunc;
	NRBTree -> freeFunc = freeFunc;
	NRBTree -> size = 0;
	return NRBTree;
}

/**
 * switch the node colors
 * @param x node
 * @param y  node
 */
void switchColor(Node* x, Node* y)
{
	Color temp = x->color;
	x->color = y->color;
	y->color = temp;
}

/**
 * flip the tree to the left ( left rotation)
 */
void flipLeft(Node* x, RBTree* tree)
{
	Node *y = x->right;
	x->right = y->left;
	if (y->left != NULL)
	{
		y->left->parent = x;
	}
	y->parent = x->parent;
	//  M root
	if (x->parent == NULL)
	{
		tree->root = y;
		y->parent = NULL;
	}
	else
	{
		if (x == x->parent->right)
		{
			x->parent->right = y;
		}
		else
		{
			x->parent->left = y;
		}
	}
	y->left = x;
	x->parent = y;
}

/**
 * flip the tree to the right ( right rotation)
 */
void flipRight(Node* x, RBTree* tree)
{
	Node *y = x->left;
	x->left = y->right;
	if (y->right != NULL)
	{
		y->right->parent = x;
	}
	y->parent = x->parent;
	//  M root
	if (x->parent == NULL)
	{
		tree->root = y;
		y->parent = NULL;
	}
	else
	{
		if (x == x->parent->left)
		{
			x->parent->left = y;
		}
		else
		{
			x->parent->right = y;
		}
	}
	y->right = x;
	x->parent = y;
}

/**
 * find the successor of node m
 * @param M node
 * @return node (m successor node)
 */
Node* successor(Node* M)
{
	if (M-> right != NULL)
	{
		M = M->right;
		while (M->left != NULL)
		{
			M = M->left;
		}
		return M;
	}
	while (M != M->parent->left)
	{
		M = M->parent;
	}
	M = M->parent;
	return M;

}

/**
 * free the node from his data
 * @param freeMe node
 * @param tree tree
 */
void freeNode(Node *freeMe, RBTree *tree)
{
	if (freeMe != NULL && tree != NULL)
	{
		tree->freeFunc(freeMe->data);
		freeMe->data = NULL;
		free(freeMe);
		freeMe = NULL;
	}

}

/**
 * return dad Node
 */
Node* myDad(Node* N)
{
	return N == NULL ? NULL: N->parent;
}

/**
 * return grandpa node
 */
Node* myGrandpa(Node* N)
{
	return myDad(myDad(N));
}

/**
 * return brother node
 */
Node* myBrother(Node* N)
{
	Node* P = myDad(N);
	if (P == NULL)
	{
		return NULL;
	}
	if (N == P->right)
	{
		return P->left;
	}
	else
	{
		return P->right;
	}
}

/**
 * return uncle node
 */
Node* myUncle(Node *N)
{
	Node* P = myDad(N);
	return myBrother(P);
}

/**
 * build and restart a node
 * @param data
 * @return node
 */
Node* buildNode(void *data)
{
	Node* new = (Node*) malloc(sizeof(Node));
	if (new == NULL)
	{
		return NULL;
	}
	new->parent = NULL;
	new->left = NULL;
	new->right = NULL;
	new->color = RED;
	new->data = data;
	return new;
}

/**
 * find the tree root
 * @param node
 * @return node (root)
 */
Node* findRoot(Node* cur)
{
	if (cur->parent == NULL)
	{
		return cur;
	}
	return findRoot(cur->parent);
}

/**
 * replace two nodes tree connection
 * @param M nodes
 * @param C nodes
 */
void replace(Node* M, Node* C)
{
	if (C != NULL)
	{
		C->parent = M->parent;
	}

	if (M == M->parent->left)
	{
		M->parent->left = C;
	}
	else
	{
		M->parent->right = C;
	}
}

/**
 * find node by data
 * @param tree tree
 * @param data val
 * @return the node that have the data if not have data like that NULL
 */
Node* findMyNode(const RBTree *tree, const void *data)
{
	Node* current = tree -> root;
	while(current != NULL)
	{
		if(tree -> compFunc(current -> data, data) > 0)
		{
			current = current -> left;
		}
		else if(tree -> compFunc(current -> data,  data) < 0)
		{
			current = current -> right;
		}
		else
		{
			return current;
		}
	}
	return current;
}

/**
 * helper recursive function freeing the memory from the nods
 */
void freeTreeHelper(FreeFunc func, Node** node)
{
	if((*node) == NULL)
	{
		return ;
	}
	if((*node) -> right != NULL)
	{
		freeTreeHelper(func, (&(*node) -> right));
	}
	if((*node) -> left != NULL)
	{
		freeTreeHelper(func, (&(*node) -> left));
	}
	func((*node)->data);
	free(*node);
	*node =  NULL;
}

/**
 * free all memory of the data structure.
 * @param tree: pointer to the tree to free.
 */
void freeRBTree(RBTree **tree)
{

	if(tree == NULL || *tree == NULL)
	{
		return;
	}
	freeTreeHelper((*tree)->freeFunc, &(*tree) -> root);

	free(*tree);
	tree = NULL;
}

/**
 * helper for "forEachRBTree" function
 */
void forEachRBTreeHelper(const RBTree* tree, Node* node, void* args, forEachFunc func)
{
	if(node == NULL)
	{
		return;
	}
	forEachRBTreeHelper(tree, node -> left, args, func);
	func(node -> data, args);
	forEachRBTreeHelper(tree, node -> right, args, func);
}

/**
 * Activate a function on each item of the tree. the order is an ascending order.
 * if one of the activations of the
 * function returns 0, the process stops.
 * @param tree: the tree with all the items.
 * @param func: the function to activate on all items.
 * @param args: more optional arguments to the function
 * (may be null if the given function support it).
 * @return: 0 on failure, other on success.
 */
int forEachRBTree(const RBTree *tree, forEachFunc func, void *args)
{
	if(tree == NULL || func == NULL)
	{
		return FAILURE;
	}
	forEachRBTreeHelper(tree, tree -> root, args, func);
	return SUCCESS;
}

/**
 * check whether the tree RBTreeContains this item.
 * @param tree: the tree to check an item in.
 * @param data: item to check.
 * @return: 0 if the item is not in the tree, other if it is.
 */
int RBTreeContains(const RBTree *tree, const void *data)
{
	if (tree == NULL)
	{
		return FAILURE;
	}
	Node* current = tree -> root;
	while(current != NULL)
	{
		if(tree -> compFunc(current -> data, data) > 0)
		{
			current = current -> left;
		}
		else if(tree -> compFunc(current -> data,  data) < 0)
		{
			current = current -> right;
		}
		else
		{
			return SUCCESS;
		}
	}
	return FAILURE;
}

/**
 * go over the node road and fix the vals in the tree to support the tree rules
 * @param M  node
 * @param tree
 */
void fixAfterInsert(Node *M, RBTree *tree);

/**
 * recursive function to the main "insert function"
 */
void insertToRBTreeHelper(Node *root, Node *n, CompareFunc func)
{

	if (root != NULL && func(n->data, root->data) < 0)
	{
		if (root->left != NULL)
		{
			return insertToRBTreeHelper(root->left, n, func);
		}
		else
		{
			root->left = n;
		}
	}
	else
	{
		if (root != NULL)
		{
			if (root->right != NULL)
			{
				return insertToRBTreeHelper(root->right, n, func);
			}
			else
			{
				root->right = n;
			}
		}
	}
	// set the root
	n->parent = root;
}

/**
 * insert helper represent insert case one situation
 */
void iCaseOne(Node* N)
{
	N->color = BLACK;
}

/**
 *  insert case Three situation
 */
void iCaseThree(Node* M, RBTree *tree)
{
	myDad(M)->color = BLACK;
	myUncle(M)->color = BLACK;
	Node *G = myGrandpa(M);
	G->color = RED;
	myGrandpa(M)->color = RED;
	fixAfterInsert(G, tree);
}

/**
 * go over the node road and fix the vals in the tree to support the tree rules
 * @param M  node
 * @param tree
 */
void fixAfterInsert(Node *M, RBTree *tree)
{
	if (myDad(M) == NULL)
	{
		iCaseOne(M);
		return;
	}
	if (myDad(M)->color != BLACK)
	{
		if (myUncle(M) != NULL && myUncle(M)->color == RED)
		{
			iCaseThree(M, tree);
		}
		//case 4
		else
		{
			Node *parent = myDad(M);
			Node *G = myGrandpa(M);
			if (M == parent->right && parent == G->left)
			{
				flipLeft(parent, tree);
				M = M->left;
			}
			else
			{
				if (M == parent->left && parent == G->right)
				{
					flipRight(parent, tree);
					M = M->right;
				}
			}
			parent = myDad(M);
			G = myGrandpa(M);
			if (M == parent->left)
			{
				flipRight(G, tree);
			}
			else
			{
				flipLeft(G, tree);
			}
			parent->color = BLACK;
			G->color = RED;
		}
	}
}

/**
 * fix thw case when the root is NULL
 */
void iRootCase(Node* M, RBTree *tree)
{
	tree->root = M;
	tree->size ++;
	M->color = BLACK;
}

/**
 * add an item to the tree
 * @param tree: the tree to add an item to.
 * @param data: item to add to the tree.
 * @return: 0 on failure, other on success. (if the item is already in the tree - failure).
 */
int insertToRBTree(RBTree *tree, void *data)
{
	// check pointers
	if (tree == NULL || data == NULL || tree->compFunc == NULL || tree->freeFunc == NULL )
	{
		return FAILURE;
	}
	if (RBTreeContains(tree, data) != 0)
	{
		return FAILURE;
	}
	// new Node
	Node *M = buildNode(data);
	if (M == NULL)
	{
		return FAILURE;
	}
	if (tree->root == NULL)
	{
		iRootCase(M, tree);
		return SUCCESS;
	}
	insertToRBTreeHelper(tree->root, M, tree->compFunc);
	tree->size ++;
	tree->root = M;
	fixAfterInsert(M, tree);
	while (myDad(tree->root) != NULL)
	{
		tree->root = myDad(tree->root);
	}
	return SUCCESS;
}

/**
 * recursion function to fix DB case in the delete action
 * @param M DB
 * @param P parent node
 * @param S brother node
 * @param tree
 */
void deleteRec(Node* M, Node* P, Node* S, RBTree *tree)
{
	// if m is a root ?
	// yes
	if (M == tree->root)
	{
		return;
	}
	// no
	else
	{
		// if s is red?
		//yes
		if (S != NULL && P != NULL && S->color == RED)
		{
			P->color = RED;
			S->color = BLACK;
			if (P->right == M)
			{
				flipRight(P, tree);
			}
			else if (P->left == M)
			{
				flipLeft(P, tree);
			}
			if (P->right != M)
			{
				S = P->right;
			}
			else
			{
				S = P->left;
			}
			deleteRec(M, P, S, tree);
			return;
		}
		// no
		else
		{
			// if two sons of s are black
			//yes
			if (((P != NULL) && (S != NULL)) && ((S->left == NULL || S->left->color == BLACK) && (
				(S->right == NULL) || S->right->color == BLACK)))
			{
				// if p is red?
				// yes
				if (P->color == RED)
				{
					P->color = BLACK;
					S->color = RED;
					return;
				}
				// no
				else
				{
					S->color = RED;
					deleteRec(P, P->parent, myBrother(P), tree);
					return;
				}
			}
			//no not 2 black sons
			else
			{
				// 3 d
				if (P->left == M && S->left != NULL && S->left->color == RED)
				{
					flipRight(S, tree);
					S->color = RED;
					S->parent->color = BLACK;
					S = S->parent;
				}
				else if (P->right == M && S->right != NULL && S->right->color == RED)
				{
					flipLeft(S, tree);
					S->color = RED;
					S->parent->color = BLACK;
					S = S->parent;
				}
				// 3 e
				if (P->left == M && S->right != NULL && S->right->color == RED)
				{
					switchColor(S, P);
					flipLeft(P, tree);
					S->right->color = BLACK;
					return;
				}
				else if (P->right == M && S->left != NULL && S->left->color == RED)
				{
					switchColor(S, P);
					flipRight(P, tree);
					S->left->color = BLACK;
					return;
				}
			}
		}
	}
}

/**
 * deal with case two in delete action
 */
void deleteCaseTwo(Node* M, Node* C, RBTree *tree)
{
	C->color = BLACK;
	if (M->parent != NULL)
	{
		replace(M, C);
	}
	else
	{
		tree->root = C;
	}
	freeNode(M, tree);
}

/**
 * remove an item from the tree
 * @param tree: the tree to remove an item from.
 * @param data: item to remove from the tree.
 * @return: 0 on failure, other on success. (if data is not in the tree - failure).
 */
int deleteFromRBTree(RBTree *tree, void *data)
{
	// pointer check
	if ( tree == NULL || data == NULL)
	{
		return FAILURE;
	}
	// check if the node exist
	if (RBTreeContains(tree, data) == 0)
	{
		return FAILURE;
	}
	Node * M = findMyNode(tree, data);
	// first tree (two kids)
	if (M->right != NULL && M->left != NULL)
	{
		Node * nodeToBeDeleted = successor(M);
		// save the s data to switch with the successor
		void * temp = M->data;
		M->data = nodeToBeDeleted->data;
		nodeToBeDeleted->data = temp;
		M = nodeToBeDeleted;
	}
	// second tree
	tree->size -= 1;
	Node *P = myDad(M);
	Node *C;
	Node *S = myBrother(M);
	if (M->right != NULL)
	{
		C = M->right;
	}
	else
	{
		C = M->left;
	}
	if (M->color == RED)
	{
		replace(M, C);
		freeNode(M, tree);
		return SUCCESS;
	}
	// M is black
	else
	{
		// c is a node?
		if ((M->right != NULL || M->left != NULL))
		{
			deleteCaseTwo(M, C, tree);
			return SUCCESS;
		}
		// c is black recur
		if (tree->root == M)
		{
			freeNode(M, tree);
			tree->root = NULL;
		}
		else
		{
			replace(M, C);
			freeNode(M, tree);
			deleteRec(C, P, S, tree);
		}
	}
	return SUCCESS;
}

