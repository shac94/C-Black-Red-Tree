/**
 * @file Structs.c
 * @author shahar cohen <shahar.cohen10@mail.huji.ac.il>
 * @cs user: shaharc1994
 * @id 205801541
 * @brief ex3, generic data ,binary tree
 */

#include "Structs.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>


# define SUCCESS  1
# define FAILURE 0

# define BIGGER 1
# define SMALLER -1
# define EQUAL 0

/**
 * CompFunc for strings (assumes strings end with "\0")
 * @param a - char* pointer
 * @param b - char* pointer
 * @return equal to 0 iff a == b. lower than 0 if a < b. Greater than 0 iff b < a. (lexicographic
 * order)
 */
int stringCompare(const void *a, const void *b)
{
	const char* stringOne;
	const char* stringTwo;

	stringOne = (const char*) a;
	stringTwo = (const char*) b;
	int res = strcmp(stringOne, stringTwo);
	return res;
}

/**
 * ForEach function that concatenates the given word and \n to pConcatenated. pConcatenated is
 * already allocated with enough space.
 * @param word - char* to add to pConcatenated
 * @param pConcatenated - char*
 * @return 0 on failure, other on success
 */
int concatenate(const void *word, void *pConcatenated)
{
	if (pConcatenated == NULL)
	{
		return FAILURE;
	}
	char const *string = (const char *) (word);
	char *pConStr = (char *) (pConcatenated);
	strcat(pConStr, string);
	strcat(pConStr, "\n");
	return SUCCESS;

}

/**
 * FreeFunc for strings
 */
void freeString(void *s)
{
	if (s != NULL)
	{
		char *str = (char *) (s);
		free(str);
		str = NULL;
		s = NULL;
	}
}

/**
 * CompFunc for Vectors, compares element by element, the vector that has the first larger
 * element is considered larger. If vectors are of different lengths and identify for the length
 * of the shorter vector, the shorter vector is considered smaller.
 * @param a - first vector
 * @param b - second vector
 * @return equal to 0 iff a == b. lower than 0 if a < b. Greater than 0 iff b < a.
 */
int vectorCompare1By1(const void *a, const void *b)
{
	if ( a == NULL && b == NULL)
	{
		return 0;
	}
	if (a == NULL)
	{
		return -1;
	}
	if (b == NULL)
	{
		return 1;
	}
	const Vector* vectorA = (const Vector*) a;
	const Vector* vectorB = (const Vector*) b;
	int smallestSize = 0;
	if (vectorA->len < vectorB->len)
	{
		smallestSize = vectorA->len;
	}
	if (vectorA->len >= vectorB->len)
	{
		smallestSize = vectorB->len;
	}
	for (int i = 0; i < smallestSize; i++)
	{
		if (vectorA->vector[i] > vectorB->vector[i])
		{
			return BIGGER;
		}
		if (vectorA->vector[i] < vectorB->vector[i])
		{
			return SMALLER;
		}
	}
	if (vectorA->len > vectorB->len)
	{
		return BIGGER;
	}
	if (vectorA->len < vectorB->len)
	{
		return SMALLER;
	}
	return EQUAL;
}

/**
 * FreeFunc for vectors
 */
void freeVector(void *pVector)
{
	if (pVector == NULL)
	{
		return;
	}
	Vector* vec = (Vector*) pVector;
	free(vec->vector);
	vec->vector = NULL;
	free(vec);
	vec = NULL;
}

/**
 * get the norm of vector
 * @param vec
 * @return norm
 */
double getNorm(const Vector* vec)
{
	if (vec == NULL)
	{
		return FAILURE;
	}
	double sum = 0;
	for ( int i = 0; i < vec->len; i++)
	{
		sum += pow(vec->vector[i], 2);
	}
	return sqrt(sum);
}

/**
 * copy pVector to pMaxVector if : 1. The norm of pVector is greater then the norm of pMaxVector.
 * 								   2. pMaxVector->vector == NULL.
 * @param pVector pointer to Vector
 * @param pMaxVector pointer to Vector that will hold a copy of the data of pVector.
 * @return 1 on success, 0 on failure (if pVector == NULL || pMaxVector==NULL: failure).
 */
int copyIfNormIsLarger(const void *pVector, void *pMaxVector)
{
	if (pMaxVector == NULL || pVector == NULL)
	{
		return FAILURE;
	}
	const Vector* vecOne = (Vector*) pVector;
	Vector* vecTwo = (Vector*) pMaxVector;
	if (vecTwo->vector == NULL)
	{
		vecTwo->vector = (double*) calloc((vecOne->len), sizeof(double));
		if( vecTwo ->vector == NULL)
		{
			return FAILURE;
		}
		for (int i = 0; i < vecOne->len; i++)
		{
			vecTwo->vector[i] = vecOne->vector[i];
		}
		vecTwo->len = vecOne->len;
		return SUCCESS;
	}
	if (getNorm(vecOne) > getNorm(vecTwo))
	{
		vecTwo->vector = (double*) realloc(vecTwo->vector, (vecTwo->len) * sizeof(double));
		if (vecTwo->vector == NULL)
		{
			return FAILURE;
		}
		for ( int i = 0; i < vecOne->len; i++)
		{
			//check
			vecTwo->vector[i] = vecOne->vector[i];
		}
		vecTwo->len = vecOne->len;
	}
	return SUCCESS;
}

/**
 * This function allocates memory it does not free.
 * @param tree a pointer to a tree of Vectors
 * @return pointer to a *copy* of the vector that has the largest norm (L2 Norm), NULL on failure.
 */
Vector *findMaxNormVectorInTree(RBTree *tree)
{
	if (tree == NULL)
	{
		return NULL;
	}
	Vector* vec = (Vector*) calloc(1, sizeof(Vector));
	if (vec == NULL)
	{
		return NULL;
	}
	if (!forEachRBTree(tree, copyIfNormIsLarger, vec))
	{
		free(vec);
		vec = NULL;
	}
	return vec;
}
